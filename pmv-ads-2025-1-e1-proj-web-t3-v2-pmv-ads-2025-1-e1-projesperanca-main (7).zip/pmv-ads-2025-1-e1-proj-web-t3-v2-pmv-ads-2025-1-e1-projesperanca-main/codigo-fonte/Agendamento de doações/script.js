let alimentosCadastrados = [];

document.getElementById("formAgendamento").addEventListener("submit", function (e) {
  e.preventDefault();

  const tipo = document.getElementById("tipo").value;
  const alimento = document.getElementById("alimento").value.trim();
  const data = document.getElementById("data").value;
  const hora = document.getElementById("hora").value;
  const local = document.getElementById("local").value.trim();
  const observacoes = document.getElementById("observacoes").value.trim();

  if (!tipo || !alimento || !data || !hora || !local) {
    alert("Por favor, preencha todos os campos obrigatórios.");
    return;
  }

  if (!alimentosCadastrados.includes(alimento)) {
    alimentosCadastrados.push(alimento);
    atualizarSugestoes();
  }

  const agendamento = { tipo, alimento, data, hora, local, observacoes };
  adicionarAgendamento(agendamento);
  this.reset();
});

function adicionarAgendamento(agendamento) {
  const lista = document.getElementById("listaAgendamentos");

  const li = document.createElement("li");
  li.innerHTML = `
    <div class="item-doacao">
      <div>
        <strong>${agendamento.tipo}</strong> - ${agendamento.alimento}<br>
        <small>${agendamento.data} às ${agendamento.hora}</small><br>
        <span>Local: ${agendamento.local}</span><br>
        ${agendamento.observacoes ? `<em>Obs: ${agendamento.observacoes}</em>` : ""}
      </div>
      <button class="btn-excluir">🗑️</button>
    </div>
  `;

  li.querySelector(".btn-excluir").addEventListener("click", function () {
    lista.removeChild(li);
  });

  lista.appendChild(li);
}

function atualizarSugestoes() {
  const datalist = document.getElementById("alimentos-lista");
  datalist.innerHTML = "";
  alimentosCadastrados.forEach(alimento => {
    const option = document.createElement("option");
    option.value = alimento;
    datalist.appendChild(option);
  });
}
