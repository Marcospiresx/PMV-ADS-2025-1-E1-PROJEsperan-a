 // Cadastro de Doações
    document.getElementById('formDoacao').addEventListener('submit', function(e) {
      e.preventDefault();
      const nome = document.getElementById('nome').value;
      const quantidade = document.getElementById('quantidade').value;
      const validade = document.getElementById('validade').value;
      const descricao = document.getElementById('descricao').value;

      const li = document.createElement('li');
      li.textContent = `${quantidade}x ${nome} (Validade: ${validade}) - ${descricao}`;
      document.getElementById('listaDoacoes').appendChild(li);

      this.reset();
    });
