document.getElementById('formCadastro').addEventListener('submit', function(event) {
    event.preventDefault();
   
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;
    const cep = document.getElementById('cep').value;
    const perfil = document.getElementById('perfil').value;
   
    const cepValido = /^[0-9]{8}$/.test(cep); // regex para 8 dígitos numéricos
   
    if (!cepValido) {
      alert("Por favor, insira um CEP válido com 8 dígitos numéricos.");
      return;
    }
   
    alert(`Cadastro realizado!
  Perfil: ${perfil}
  Nome: ${nome}
  Email: ${email}
  CEP: ${cep}`);
  });