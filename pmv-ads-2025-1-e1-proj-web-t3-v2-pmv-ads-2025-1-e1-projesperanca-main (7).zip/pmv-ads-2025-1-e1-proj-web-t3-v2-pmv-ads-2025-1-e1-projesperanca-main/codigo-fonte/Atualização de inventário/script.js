let estoque = [];
let doacoesPendentes = [];

document.getElementById('formDoacao').addEventListener('submit', function(event) {
  event.preventDefault();

  const nome = document.getElementById('alimento').value.trim();
  const quantidade = parseInt(document.getElementById('quantidade').value);
  const validade = document.getElementById('validade').value;

  if (!nome || quantidade < 1 || !validade) return;

  const item = estoque.find(i => i.nome.toLowerCase() === nome.toLowerCase());

  if (!item || item.quantidade < quantidade) {
    alert("Item não disponível em estoque ou quantidade insuficiente.");
    return;
  }

  // Atualiza o estoque
  item.quantidade -= quantidade;
  if (item.quantidade === 0) {
    estoque = estoque.filter(i => i !== item);
  }

  // Adiciona à lista de doações pendentes
  doacoesPendentes.push({
    nome,
    quantidade,
    validade,
    data: new Date().toLocaleString()
  });

  atualizarTabelas();
  event.target.reset();
});

function atualizarTabelas() {
  const tbodyEstoque = document.getElementById('tabelaEstoque').querySelector('tbody');
  const tbodyPendentes = document.getElementById('tabelaPendentes').querySelector('tbody');

  tbodyEstoque.innerHTML = '';
  estoque.forEach(item => {
    const row = `<tr><td>${item.nome}</td><td>${item.quantidade}</td></tr>`;
    tbodyEstoque.innerHTML += row;
  });

  tbodyPendentes.innerHTML = '';
  doacoesPendentes.forEach((doacao, index) => {
    const row = `
      <tr>
        <td>${doacao.nome}</td>
        <td>${doacao.quantidade}</td>
        <td>${doacao.validade}</td>
        <td>${doacao.data}</td>
        <td><button class="entregar" onclick="realizarDoacao(${index})">Entregue</button></td>
      </tr>
    `;
    tbodyPendentes.innerHTML += row;
  });
}

function realizarDoacao(index) {
  doacoesPendentes.splice(index, 1); // Remove a doação da lista
  atualizarTabelas();
}

// Não inicializa com alguns itens no estoque
estoque.push({ nome: "Arroz", quantidade: 0 });
estoque.push({ nome: "Feijão", quantidade: 0 });
estoque.push({ nome: "Macarrão", quantidade: 0 });

atualizarTabelas();
