# Apresentação do Projeto

## Conjunto de Slides

[Projeto Semeando Esperança.pdf](https://github.com/user-attachments/files/20030523/Projeto.Semeando.Esperanca.pdf)


## Vídeo de apresentação

A equipe também deverá gravar um vídeo de, no máximo, três minutos, com a apresentação da solução. Vocês deverão abrir a aplicação hospedada e apresentar o seu funcionamento.  Poderão ser utilizados quaisquer recursos na montagem do vídeo, mas não se esqueçam de mostrar as funcionalidades da aplicação. Seguem as especificações técnicas que devem ser obedecidas na geração do vídeo:

> - tamanho do arquivo limitado a 90Mb
> - taxa de FPS limitada a 30 quadros por segundo
> - resolução HD (720p) ou Full HD (1080p)
> - formato mp4.

[recording-2025-06-06-22-34-05.webm](https://github.com/user-attachments/assets/6522aa66-5bc8-46fb-a8da-adbb7749cec4)


## Hospedagem

[Adicione o endereço eletrônico público onde o site encontra-se hospedado.]
