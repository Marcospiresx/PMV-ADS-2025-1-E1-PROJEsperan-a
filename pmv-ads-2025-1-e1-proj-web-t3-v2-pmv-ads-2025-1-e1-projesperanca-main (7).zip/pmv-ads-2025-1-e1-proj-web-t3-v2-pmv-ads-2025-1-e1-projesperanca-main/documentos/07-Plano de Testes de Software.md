# Plano de Testes de Software

[Apresente os cenários de testes a serem utilizados na realização dos testes da aplicação. Escolha cenários de testes que demonstrem os requisitos sendo atendidos. ]

Os testes funcionais a serem realizados na aplicação são descritos a seguir. [Utilize a estrutura abaixo para cada caso de teste]

|Caso de Teste    | CT-X - Título Caso de Teste |
|:---|:---|
| Requisitos Associados | RF-X |
| Objetivo do Teste | Descrição do objetivo do teste |
| Passos | Indicar passos para a execução do teste |
| Critérios de êxito | Indicar os critérios de êxito  |
| Responsável pela elaborar do caso de Teste | Nome do integrante da equipe |

---
| Caso de Teste                              | CT-01 - Navegação entre páginas                                                                        |
| :----------------------------------------- | :----------------------------------------------------------------------------------------------------- |
| Requisitos Associados                      | RF-01                                                                                                 |
| Objetivo do Teste                          | Verificar se a navegação entre as seções funciona corretamente                                         |
| Passos                                     | 1. Acessar o site<br>2. Clicar em cada link do menu (Home, Cadastro, Agendamento, Cadastro de Usuário) |
| Critérios de êxito                         | A seção correspondente deve ser exibida com conteúdo visível e as demais ocultadas                     |
| Responsável pela elaborar do caso de Teste | Ruan Mulato                                                                                             |

---

| Caso de Teste                              | CT-02 - Cadastro de doações                                                                                     |
| :----------------------------------------- | :-------------------------------------------------------------------------------------------------------------- |
| Requisitos Associados                      | RF-02                                                                                                           |
| Objetivo do Teste                          | Verificar se é possível cadastrar uma doação com os dados exigidos                                              |
| Passos                                     | 1. Navegar até a aba "Cadastro"<br>2. Preencher todos os campos obrigatórios<br>3. Clicar em "Cadastrar Doação" |
| Critérios de êxito                         | A doação deve aparecer listada em "Doações Cadastradas"                                                         |
| Responsável pela elaborar do caso de Teste | Marcos Antonio    |

---


| Caso de Teste                              | CT-03 - Agendamento de entrega ou retirada                                                                                   |
|  :----------------------------------------- | :-----------------------------------------------------------------------------------------------------|
| Requisitos Associados                      | RF-05                                                                                                           |
| Objetivo do Teste                          | Validar o agendamento de alimentos com tipo, data, hora e local                                              |
| Passos                                     | 1. Navegar até "Agendamento"2. Preencher o formulário3. Clicar em "Agendar" |
| Critérios de êxito                         | O agendamento deve aparecer na lista de agendamentos                                                       |
| Responsável pela elaborar do caso de Teste | Carlos Eduardo                                                         |

---

| Caso de Teste                              | CT - 04 - Validação do campo "Alimento" no cadastro de doações                                                                     |
| :----------------------------------------- | :-------------------------------------------------------------------------------------------------------------- |
| Requisitos Associados                      | RF-04                                                                                                           |
| Objetivo do Teste                          | Verificar se o campo "Alimento" é obrigatório                                              |
| Passos                                     | 1. Deixar o campo "Alimento" vazio2. Tentar enviar o formulário |
| Critérios de êxito                         | O formulário deve impedir o envio                                                       |
| Responsável pela elaborar do caso de Teste | Tainan Marques Gadelha                                                         |

---

| Caso de Teste                              | CT-5 - Validação do campo "Nome de Usuário" no cadastro de usuário              |
| :----------------------------------------- | :------------------------------------------------------------------------------- |
| Requisitos Associados                      | RF-04                                                                            |
| Objetivo do Teste                          | Validar que o campo "Nome" do usuário não aceite números ou caracteres especiais |
| Passos                                     | 1. Inserir nome com números (ex: Ana123)<br>2. Tentar cadastrar                  |
| Critérios de êxito                         | O sistema deve impedir o envio e indicar erro                                    |
| Responsável pela elaborar do caso de Teste | Ruan Mulato       


---


| Caso de Teste            | CT - 06 Cadastro de Usuário com validação de CEP                                               |
|--------------------------|------------------------------------------------------------------------------------------------|
| Requisitos Associados    | RF-06                                                                                          |
| Objetivo do Teste    | Verificar se o campo "CEP" aceita apenas o formato correto (00000-000 ou 00000000)            |
| Passos              | 1. Navegar até a aba "Cadastro de Usuário" <br> 2. Inserir um CEP inválido (ex.: 1234567, 1234) <br> 3. Tentar cadastrar |
| Critérios de êxito   | O sistema deve impedir o envio do formulário e exibir uma mensagem de erro indicando CEP inválido. |
| Responsável          | Ruan Mulato                                                                                 |

---



| Caso de Teste                        |  CT-07 Validação de Data no Agendamento                                            |
|--------------------------|------------------------------------------------------------------------------------------------|
| Requisitos Associados| RF-07                                                                                          |
| Objetivo do Teste  | Garantir que não seja possível agendar uma entrega ou retirada com data anterior à atual      |
| Passos               | 1. Navegar até "Agendamento" <br> 2. Preencher o formulário com uma data anterior à data atual <br> 3. Tentar agendar |
| Critérios de êxito  | O sistema deve bloquear o agendamento e exibir mensagem informando que a data deve ser igual ou posterior à data atual |
| Responsável       | Carlos Eduardo                                                                        |

---



|  Caso de Teste                          | CT 08 - Cadastro de Doação sem quantidade                                               |
|--------------------------|------------------------------------------------------------------------------------------------|
| Requisitos Associados| RF-08                                                                                          |
| Objetivo do Teste    | Validar se o campo "Quantidade" no cadastro de doações é obrigatório e não aceita valores nulos ou menores que 1 |
| Passos             | 1. Navegar até "Cadastro" <br> 2. Deixar o campo "Quantidade" vazio ou colocar valor 0 <br> 3. Tentar cadastrar |
| Critérios de êxito   | O sistema deve impedir o envio do formulário, exibindo uma mensagem de erro indicando que a quantidade deve ser no mínimo 1 |
| Responsável         | Carlos Eduardo                                                                                 |

---







 
> **Links Úteis**:
> - [IBM - Criação e Geração de Planos de Teste](https://www.ibm.com/developerworks/br/local/rational/criacao_geracao_planos_testes_software/index.html)
> -  [Teste de Software: Conceitos e tipos de testes](https://blog.onedaytesting.com.br/teste-de-software/)
> - [Criação e Geração de Planos de Teste de Software](https://www.ibm.com/developerworks/br/local/rational/criacao_geracao_planos_testes_software/index.html)
> - [Ferramentas de Test para Java Script](https://geekflare.com/javascript-unit-testing/)
> - [UX Tools](https://uxdesign.cc/ux-user-research-and-user-testing-tools-2d339d379dc7)
