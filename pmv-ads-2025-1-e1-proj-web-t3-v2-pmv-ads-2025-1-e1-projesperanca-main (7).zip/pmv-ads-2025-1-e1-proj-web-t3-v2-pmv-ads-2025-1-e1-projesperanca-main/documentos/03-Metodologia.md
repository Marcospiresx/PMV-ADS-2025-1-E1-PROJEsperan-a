
# Metodologia

A metodologia adotada para o desenvolvimento do software de planejamento de doações de alimentos será baseada na abordagem ágil, utilizando Scrum como framework de gestão. Isso permitirá entregas incrementais, maior adaptação a mudanças e colaboração contínua entre os membros da equipe.


## Gerenciamento de Projeto
### Introdução 
A metodologia ágil SCRUM foi escolhida para o desenvolvimento do Sistema de Doação de Alimentos devido aos seus benefícios, como:
- Visão clara dos resultados esperados;
- Ritmo e disciplina na execução do projeto;
- Definição clara dos papéis e responsabilidades;
- Empoderamento da equipe para alcançar os objetivos;
- Compartilhamento de conhecimento de forma colaborativa;
- Ambiente favorável para feedback contínuo e melhoria contínua.

### Papéis no projeto
- Product Owner (PO): Responsável por definir e priorizar os requisitos do sistema, garantindo que as necessidades dos usuários finais sejam atendidas.

- Scrum Master: Facilita a aplicação da metodologia, removendo impedimentos e garantindo que a equipe siga os princípios do SCRUM.

- Time de Desenvolvimento: Grupo multidisciplinar responsável pela implementação das funcionalidades do sistema, incluindo desenvolvedores, designers e testadores.

### Metódos no Scrum 
- Product Backlog: Lista priorizada de todas as funcionalidades e melhorias a serem implementadas no sistema.
- Sprint Backlog: Conjunto de tarefas selecionadas para serem desenvolvidas dentro da Sprint atual
- Incremento: Entregável ao final de cada Sprint, representando um conjunto de funcionalidades testadas e prontas para uso.

### Divisão de Papéis

A equipe utiliza o Scrum como base para definição do processo de desenvolvimento.
Exemplificação: A equipe utiliza metodologias ágeis, tendo escolhido o Scrum como base para definição do processo de desenvolvimento. A equipe está organizada da seguinte maneira:

- Scrum Master: Tainan Marques;
- Product Owner: Carlos Silva;
- Equipe de Desenvolvimento: Marcos Antonio, Ruan Mulato;
- Equipe de Design: Tainan Marques.

  ### Encontros do Scrum
  - Sprint Planning (Planejamento da Sprint): Reunião inicial de cada Sprint para definir as tarefas a serem realizadas.
  - Daily Scrum (Reunião Diária): Reuniões curtas para acompanhar o progresso, discutir desafios e alinhar prioridades.
  -  Sprint Review (Revisão da Sprint): Apresentação dos incrementos desenvolvidos para avaliação e feedback.
  -  Sprint Retrospective (Retrospectiva da Sprint): Reunião final para analisar o que funcionou bem e o que pode ser melhorado na próxima Sprint.


  ###  Ciclo de Desenvolvimento
 - Duração da Sprint: 2 a 4 semanas
 - Entrega Contínua: Cada Sprint gera um incremento funcional do sistema
 - Feedback Contínuo: Melhorias constantes com base na interação com usuários e stakeholders



 
> **Links Úteis**:
> - [11 Passos Essenciais para Implantar Scrum no seu 
> Projeto](https://mindmaster.com.br/scrum-11-passos/)
> - [Scrum em 9 minutos](https://www.youtube.com/watch?v=XfvQWnRgxG0)

### Processo

O trabalho será dividido em sprints de duas semanas, com reuniões de planejamento, daily meetings curtas para alinhamento, revisão de sprint e retrospectiva para melhorias contínuas.
- Backlog: ✅ Criar funcionalidade de cadastro de doadores e beneficiários.
✅ Desenvolver tela para registro de alimentos para doação.
✅ Implementar autenticação de usuários com login e senha.
✅ Definir padrões de design para melhorar usabilidade.

- To Do: ✅ Criar API para cadastro de alimentos.
✅ Desenvolver interface para visualização das necessidades das ONGs e abrigos.
✅ Implementar funcionalidade de notificações para doadores e beneficiários.
✅ Criar relatório de doações realizadas.

- Doing:🛠 Desenvolvimento da interface de agendamento de retirada e entrega.
🛠 Implementação de segurança no login.
🛠 Testes de compatibilidade do sistema em dispositivos móveis.
🛠 Correção de bugs na tela de cadastro de voluntários.

- Done: ✅ Concluído o cadastro de beneficiários.
✅ Implementado o sistema de notificações.
✅ Testes de usabilidade aprovados.

> **Links Úteis**:
> - [Project management, made simple](https://github.com/features/project-management/)
> - [Sobre quadros de projeto](https://docs.github.com/pt/github/managing-your-work-on-github/about-project-boards)
> - [Como criar Backlogs no Github](https://www.youtube.com/watch?v=RXEy6CFu9Hk)
> - [Tutorial Slack](https://slack.com/intl/en-br/)


### Etiquetas
<p>As tarefas são, ainda, etiquetadas em função da natureza da atividade e seguem o seguinte esquema de cores/categorias:</p>

<ul>
  <li>Bug (Erro no código)</li>
  <li>Desenvolvimento (Development)</li>
  <li>Documentação (Documentation)</li>
  <li>Gerência de Projetos (Project Management)</li>
  <li>Infraestrutura (Infrastructure)</li>
  <li>Testes (Tests)</li>
</ul>

<figure> 
  <img src="https://user-images.githubusercontent.com/100447878/164068979-9eed46e1-9b44-461e-ab88-c2388e6767a1.png"
    <figcaption>Figura 3 - Tela do esquema de cores e categorias</figcaption>
</figure> 
  
### Ferramentas

[Descreva aqui as ferramentas empregadas no projeto e os ambiente de trabalho utilizados pela  equipe para desenvolvê-lo. Abrange a relação de ambientes utilizados, a estrutura para gestão do código fonte, além da definição do processo e ferramenta através dos quais a equipe se organiza (Gestão de Times).]

Os artefatos do projeto são desenvolvidos a partir de diversas plataformas e a relação dos ambientes com seu respectivo propósito é apresentada na tabela que se segue.

| AMBIENTE                            | PLATAFORMA                         | LINK DE ACESSO                         |
|-------------------------------------|------------------------------------|----------------------------------------|
| Repositório de código fonte         | GitHub                             | https://github.com/ICEI-PUC-Minas-PMV-ADS/pmv-ads-2025-1-e1-proj-web-t3-v2-pmv-ads-2025-1-e1-projesperanca/tree/main/codigo-fonte                     |
| Documentos do projeto               | GitHub                             |   https://github.com/ICEI-PUC-Minas-PMV-ADS/pmv-ads-2025-1-e1-proj-web-t3-v2-pmv-ads-2025-1-e1-projesperanca/tree/main/documentos                          |
| Projeto de Interface                | User Flow                             |  https://clickup.com/templates/user-flow-t-200540385?utm_source=google-pmax&utm_medium=cpc&utm_campaign=gpm_cpc_ar_nnc_pro_trial_all-devices_tcpa_lp_x_all-departments_x_pmax&utm_content=&utm_creative=_____&gad_source=1&gclid=EAIaIQobChMI-Y241JXEjAMVR0FIAB3UEhLFEAAYASAAEgIMlvD_BwE                         |
| Gerenciamento do Projeto            | GitHub Projects                    |   https://github.com/ICEI-PUC-Minas-PMV-ADS/pmv-ads-2025-1-e1-proj-web-t3-v2-pmv-ads-2025-1-e1-projesperanca/tree/main/codigo-fonte                     |
| Hospedagem                          | GitHub Pages                       |   https://github.com/ICEI-PUC-Minas-PMV-ADS/pmv-ads-2025-1-e1-proj-web-t3-v2-pmv-ads-2025-1-e1-projesperanca/tree/main/codigo-fonte                        |


### Estratégia de Organização de Codificação 

Toda nossa estrategia de organização que foi aplicado neste projeto foi inserido na pasta de https://github.com/ICEI-PUC-Minas-PMV-ADS/pmv-ads-2025-1-e1-proj-web-t3-v2-pmv-ads-2025-1-e1-projesperanca/tree/main/codigo-fonte
