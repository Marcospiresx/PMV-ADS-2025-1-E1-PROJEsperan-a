# Registro de Testes de Software

Relatório com as evidências dos testes de software realizados na aplicação pela equipe, baseado no plano de testes pré-definido.

Os resultados dos testes funcionais realizados na aplicação são descritos a seguir. [Utilize a estrutura abaixo para cada caso de teste executado]

|Caso de Teste    | CT-X - Título Caso de Teste |
|:---|:---|
| Resultados obtidos | Descrever resultados do teste  |
| Responsável pela execução do caso de Teste | Nome do integrante da equipe |

[Inserir aqui as evidências de teste que podem ser apresentadas por print de telas ou por .gif de execução de teste]


|Caso de Teste    |  CT-01 - Navegação entre páginas  |
|:---|:---|
| Resultados obtidos | O sistema permitiu a navegação entre as páginas com sucesso.  |
| Responsável pela execução do caso de Teste | Ruan Mulato |

![Teste-de-navegaçao-pages](https://github.com/user-attachments/assets/a0e8b30b-aa91-4e78-a91b-f777afe023c0)


|Caso de Teste    | CT-02 - Cadastro de doações |
|:---|:---|
| Resultados obtidos | O sistema permitiu o cadastro de doações com sucesso. |
| Responsável pela execução do caso de Teste | Tainan Gadelha |
|![recording-2025-06-08-16-16-56](https://github.com/user-attachments/assets/415c9fe8-05be-4f89-b4d1-cf78c4b7b5f5)


|Caso de Teste    | CT-03 - Agendamento de entrega ou retirada |
|:---|:---|
| Resultados obtidos | O sistema permitiu o agendamento de entrega/retirada com sucesso.  |
| Responsável pela execução do caso de Teste | Carlos Eduardo  |
![2025-06-08 07-50-56 mkv](https://github.com/user-attachments/assets/00c07317-1ad7-4d1a-89f0-cda4a39b01ff)

|Caso de Teste    | CT - 04 - Validação do campo "Alimento" no cadastro de doações |
|:---|:---|
| Resultados obtidos | O sistema considerou o campo "Alimento" como obrigatório. |
| Responsável pela execução do caso de Teste | Marcos Antônio |
|![recording-2025-06-08-16-10-33](https://github.com/user-attachments/assets/4f9f3dd0-d06a-4e68-a6a0-5e80a205699e) 

|Caso de Teste    | CT-05 - Validação do campo "Nome de Usuário" no cadastro de usuário   |
|:---|:---|
| Resultados obtidos | O sistema considerou o campo "Nome de Usuário" como obrigatório.  |
| Responsável pela execução do caso de Teste |  Ruan Mulato   |
![2025-06-08-11-30-04](https://github.com/user-attachments/assets/70c76c21-c9ea-4cce-ac57-717e32562669)


|Caso de Teste    | CT - 06 Cadastro de Usuário com validação de CEP |
|:---|:---|
| Resultados obtidos | O sistema considerou o preenchimento do campo do CEP como obrigatório  |
| Responsável pela execução do caso de Teste | Ruan Mulato |

![teste-de-validacao-de-cep](https://github.com/user-attachments/assets/f12759a7-1423-4aa7-9be6-af61d2001040)


|Caso de Teste    | CT-07 Validação de Data no Agendamento |
|:---|:---|
| Resultados obtidos | O sistema não permitiu o cadastro sem a data preenchida e não permitiu que o agendamento fosse em uma data passada.  |
| Responsável pela execução do caso de Teste | Carlos Eduardo  |
![2025-06-08-12-32-56](https://github.com/user-attachments/assets/ed01ff70-b32f-4f58-9a46-bef2bb3f21cb)

|Caso de Teste    | CT 08 - Validar se o campo "quantidade" é obrigatório |
|:---|:---|
| Resultados obtidos | O sistema considerou o campo "quantidade" como obrigatório.  |
| Responsável pela execução do caso de Teste | Carlos Eduardo |
![2025-06-08-12-16-04](https://github.com/user-attachments/assets/24253ce3-0686-48e9-9bb2-44d51d71d9cf)
