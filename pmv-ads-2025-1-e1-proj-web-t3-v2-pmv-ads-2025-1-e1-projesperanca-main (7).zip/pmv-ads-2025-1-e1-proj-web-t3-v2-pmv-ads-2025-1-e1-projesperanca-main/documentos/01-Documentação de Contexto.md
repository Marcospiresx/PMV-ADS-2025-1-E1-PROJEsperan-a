# Introdução

A fome é uma realidade cruel que afeta milhões de pessoas diariamente, tornando-se um dos problemas sociais mais urgentes da atualidade, não só no Brasil, mas no mundo inteiro. Enquanto toneladas de alimentos são desperdiçadas todos os dias, uma parcela significativa da população enfrenta a incerteza de não saber quando terá a próxima refeição. Esse contraste evidencia a desigualdade no acesso à alimentação e ressalta a necessidade de medidas que promovam um melhor aproveitamento dos recursos disponíveis.

Essa situação é ainda mais grave em comunidades vulneráveis, onde a escassez de alimentos se soma a outros desafios, como o desemprego, a falta de infraestrutura e o difícil acesso a serviços básicos. Sem políticas públicas eficazes e sem iniciativas que incentivem a distribuição justa dos alimentos, muitas dessas pessoas permanecem em condições de extrema necessidade.

Diante desse cenário, é fundamental buscar soluções que incentivem a solidariedade e a redistribuição responsável de alimentos. Conectar aqueles que podem doar com aqueles que mais precisam é um passo essencial para reduzir o desperdício e minimizar o impacto da fome. Além disso, o fortalecimento de redes de apoio e o uso da tecnologia como facilitadora desse processo podem contribuir significativamente para a construção de uma sociedade mais justa e solidária.

## Problema
A fome e o desperdício de alimentos são problemas interligados que afetam milhões de pessoas no Brasil e no mundo. De acordo com a FAO (Organização das Nações Unidas para a Alimentação e a Agricultura), cerca de 1,3 bilhão de toneladas de alimentos são desperdiçadas anualmente no mundo, o que equivale a quase um terço de toda a produção global. No Brasil, a Sociedade Brasileira de Varejo e Consumo (SBVC) estima que aproximadamente 30% dos alimentos produzidos no país são descartados, representando uma perda de cerca de 46 milhões de toneladas por ano. Esse desperdício gera um impacto econômico significativo, estimado em R$ 61,3 bilhões anuais.

Ao mesmo tempo, dados do IBGE (Instituto Brasileiro de Geografia e Estatística) indicam que mais de 60 milhões de brasileiros vivem em situação de insegurança alimentar, ou seja, sem acesso regular a alimentos em quantidade e qualidade adequadas. Essa realidade reflete uma profunda desigualdade social e uma falha estrutural nos sistemas de produção, distribuição e reaproveitamento de alimentos.

Entre os principais fatores que contribuem para esse cenário estão falhas na logística, a falta de incentivos para a doação de excedentes alimentares e a ausência de políticas públicas eficazes para a redistribuição de comida. Segundo o Programa das Nações Unidas para o Meio Ambiente (PNUMA), aproximadamente 17% de todos os alimentos disponíveis aos consumidores foram desperdiçados em 2019, evidenciando a necessidade de soluções que otimizem o aproveitamento desses recursos.

Diante desse contexto, torna-se essencial buscar alternativas que reduzam o desperdício e garantam que alimentos próprios para consumo cheguem a quem mais precisa. A implementação de estratégias que conectem doadores e beneficiários pode contribuir significativamente para minimizar esse problema, promovendo um melhor aproveitamento dos recursos alimentares disponíveis e incentivando uma cultura de solidariedade e responsabilidade social.


## Objetivos

Objetivo Geral

Desenvolver uma plataforma digital acessível e eficiente para conectar doadores de alimentos (como restaurantes, supermercados e ONGs) a beneficiários em situação de vulnerabilidade, visando reduzir o desperdício de alimentos e combater a fome, promovendo uma distribuição mais justa e consciente desses recursos.

Objetivos Específicos

1. Facilitar a redistribuição de alimentos ao criar um sistema que permita aos doadores e beneficiários se conectarem de maneira simples e eficiente, promovendo uma gestão transparente das doações.

2. Promover a acessibilidade e a inclusão digital ao garantir que a plataforma seja fácil de usar para diversos perfis de usuários, incluindo aqueles com pouca familiaridade com tecnologia.

3. Garantir a segurança e a confiabilidade das doações, por meio de um sistema que permita o monitoramento e a verificação das transações, garantindo que os alimentos oferecidos sejam próprios para consumo e que o processo seja realizado de forma ética e transparente.
 

## Justificativa

O desperdício de alimentos é um problema global que contrasta diretamente com a fome e a insegurança alimentar enfrentadas por milhões de pessoas. De acordo com o Programa das Nações Unidas para o Meio Ambiente (PNUMA), cerca de 17% de todos os alimentos disponíveis aos consumidores foram desperdiçados em 2019, totalizando aproximadamente 931 milhões de toneladas. Esse dado ilustra o desequilíbrio entre a produção e o consumo de alimentos, onde uma grande quantidade é descartada enquanto milhões de pessoas ainda enfrentam dificuldades para se alimentar adequadamente. No Brasil, de acordo com a Sociedade Brasileira de Varejo e Consumo (SBVC), cerca de 30% dos alimentos produzidos no país são desperdiçados, o que representa 46 milhões de toneladas anuais. O desperdício alimenta um ciclo de ineficiência, enquanto, por outro lado, mais de 60 milhões de brasileiros ainda sofrem de insegurança alimentar, ou seja, não têm acesso regular a alimentos suficientes e de qualidade (IBGE, 2021).

Diante desse cenário alarmante, a criação de uma plataforma de doação de alimentos surge como uma solução prática e acessível para minimizar esses problemas. O projeto busca conectar de maneira eficiente os doadores (como restaurantes, supermercados e cidadãos) aos beneficiários (como ONGs, bancos de alimentos e indivíduos em situação de vulnerabilidade). A tecnologia, ao facilitar essa conexão, pode desempenhar um papel crucial na redistribuição organizada de alimentos próximos do vencimento ou sobras seguras para consumo. Isso não só contribuiria para reduzir o desperdício de alimentos, mas também ajudaria a mitigar a fome de uma maneira mais sustentável.

A motivação por trás deste projeto se fundamenta na necessidade urgente de atuar sobre um problema global que afeta tanto a sociedade quanto o meio ambiente. Segundo a FAO (Organização das Nações Unidas para a Alimentação e a Agricultura), aproximadamente 1,3 bilhões de toneladas de alimentos são desperdiçadas anualmente no mundo, enquanto a fome e a insegurança alimentar continuam a ser um problema persistente. A escolha de trabalhar com esse problema está diretamente relacionada à busca por soluções inovadoras que utilizem a tecnologia para conectar aqueles que têm alimentos disponíveis aos que mais precisam.

Além disso, ao adotar uma abordagem baseada na solidariedade e na responsabilidade social, o projeto tem o potencial de gerar um impacto positivo tanto social quanto ambiental. Ao incentivar práticas mais sustentáveis e solidárias, a plataforma pode estimular um ciclo de aproveitamento consciente dos recursos alimentares, onde empresas e indivíduos se engajam ativamente na construção de uma sociedade mais justa e sustentável.


## Público-Alvo

Para o desenvolvimento da aplicação, é fundamental identificar e compreender os diferentes perfis de usuários que interagem com o problema do desperdício de alimentos. O projeto se destina principalmente a dois grupos de atores: doadores e beneficiários. Cada grupo possui características, necessidades e níveis variados de experiência com tecnologia, o que influencia diretamente o design e a funcionalidade da plataforma. 

 

Doadores: 

Quem são: Restaurantes, supermercados, produtores locais e cidadãos com excedentes de alimentos. 

Na aplicação: Esses usuários se cadastram como doadores, publicam informações sobre as doações (incluindo descrição e endereço para retirada) e acompanham os agendamentos. 

Perfil tecnológico: Geralmente possuem um nível intermediário a avançado de familiaridade com plataformas digitais e sistemas de gestão, facilitando o cadastro e a inserção de informações sobre as doações. 

Necessidades: Uma interface intuitiva para cadastro rápido, gerenciamento eficiente das doações e transparência no processo de doação. 

Beneficiários: 

Quem são: Instituições sociais (como bancos de alimentos, ONGs e abrigos) e indivíduos em situação de vulnerabilidade. 

Na aplicação: Esses usuários se registram como recebedores e utilizam a plataforma para agendar a retirada dos alimentos doados, de acordo com suas necessidades e disponibilidade. 

Necessidades: Uma plataforma acessível e fácil de navegar, com instruções claras e recursos de suporte que garantam um agendamento seguro e descomplicado. 

 

Com essa abordagem, a aplicação atende de forma inclusiva ambos os perfis, promovendo a redução do desperdício de alimentos e facilitando a conexão entre quem doa e quem precisa. 


