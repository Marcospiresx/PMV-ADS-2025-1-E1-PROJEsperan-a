# Referências Bibliográficas
https://github.com/ICEI-PUC-Minas-PMV-ADS/pmv-ads-2025-1-e1-proj-web-t3-v2-pmv-ads-2025-1-e1-projesperanca/tree/main/codigo-fonte
	https://github.com/ICEI-PUC-Minas-PMV-ADS/pmv-ads-2025-1-e1-proj-web-t3-v2-pmv-ads-2025-1-e1-projesperanca/tree/main/documentos
	https://clickup.com/templates/user-flow-t-200540385?utm_source=google-pmax&utm_medium=cpc&utm_campaign=gpm_cpc_ar_nnc_pro_trial_all-devices_tcpa_lp_x_all-departments_x_pmax&utm_content=&utm_creative=_____&gad_source=1&gclid=EAIaIQobChMI-Y241JXEjAMVR0FIAB3UEhLFEAAYASAAEgIMlvD_BwE
		https://github.com/ICEI-PUC-Minas-PMV-ADS/pmv-ads-2025-1-e1-proj-web-t3-v2-pmv-ads-2025-1-e1-projesperanca/tree/main/codigo-fonte
https://github.com/ICEI-PUC-Minas-PMV-ADS/pmv-ads-2025-1-e1-proj-web-t3-v2-pmv-ads-2025-1-e1-projesperanca/tree/main/codigo-fonte)



livro: Fundamentos da Arquitetura de Software: uma Abordagem de Engenharia - por Mark Richards (Autor), Neal Ford (Autor)


livro: Gestão de Projetos - Preditiva, Ágil e Estratégica -  por Antonio Cesar Amaru Maximiano (Autor), Fernando Veroneze (Autor)

> **Links Úteis**:
> - [Formato ABNT](https://www.normastecnicas.com/abnt/)
> - [Referências Bibliográficas da ABNT](https://comunidade.rockcontent.com/referencia-bibliografica-abnt/)
