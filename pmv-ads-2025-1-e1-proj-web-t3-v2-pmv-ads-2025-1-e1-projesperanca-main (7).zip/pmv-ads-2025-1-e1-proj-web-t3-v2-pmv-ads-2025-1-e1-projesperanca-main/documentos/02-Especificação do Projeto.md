# Especificação do Projeto

Este projeto visa desenvolver um aplicativo para facilitar a doação de alimentos entre doadores, ONGs, abrigos e beneficiários, oferecendo uma plataforma simples e eficaz para quem deseja doar ou receber alimentos. O objetivo é solucionar problemas logísticos de distribuição e aumentar o impacto das doações de alimentos para populações carentes.

## Perfis de Usuários

| Perfil | Necessidades  ||           
|--------------------|------------------------------------|----------------------------------------|
| Doador - Maria               |  Maria é dona de uma pequena padaria e quer ajudar a comunidade local. Ela está interessada em um meio simples e rápido para fazer suas doações de pães e outros alimentos não perecíveis. Maria busca uma plataforma confiável para fazer suas doações de forma direta para ONGs ou abrigos de sua cidade. |                  |   
|  ONG - João                 | João coordena uma ONG que oferece alimentação para pessoas em situação de rua. Ele precisa de um aplicativo que centralize as doações recebidas e facilite o gerenciamento das entregas aos beneficiários. A ONG busca otimizar a distribuição de alimentos            |                                          |   
|  Beneficiário - Ana         |  Ana é moradora de rua e depende das doações de alimentos para sua sobrevivência. Ela precisa de um sistema onde possa localizar rapidamente as ONGs ou abrigos que estão distribuindo alimentos em sua região, com horários e locais definidos.                         |                                          |   
|  Abrigo -   Pedro           |   Pedro administra um abrigo para famílias em situação de vulnerabilidade social. O abrigo precisa de um aplicativo para gerenciar as doações e as necessidades alimentícias de seus moradores, garantindo que tudo seja distribuído de maneira justa e eficiente.                        |                                          |   



## Histórias de Usuários

|EU COMO| QUERO/PRECISO  |PARA                |
|--------------------|------------------------------------|----------------------------------------|
|Doador (Maria) | Cadastrar minha padaria para doação de alimentos | Ajudar pessoas necessitadas em minha cidade|
|Doador (Carlos)| Visualizar o histórico de doações realizadas     | Monitorar o impacto das minhas contribuições|
|Doador (João)  | Receber sugestões de ONGs ou abrigos próximos para onde posso fazer doações| Facilitar o processo de entrega de alimentos sem perder tempo|


-----------------------------------------------------------------------------------------------------------------

|EU COMO| QUERO/PRECISO  |PARA                 |
|--------------------|------------------------------------|----------------------------------------|
| ONG (João)         | Receber notificações de doações perto de mim  | Organizar e planejar a retirada de alimentos de forma eficiente|
| ONG (Carla)        | Gerenciar as doações recebidas, incluindo a quantidade e o tipo de alimento  | Planejar melhor a distribuição para os beneficiários|
| ONG (Lúcia)        | Consultar a disponibilidade de alimentos em tempo real |Organizar rapidamente as entregas e atender as necessidades emergenciais  |




------------------------------------------------------------------------------------------------------------------

|EU COMO| QUERO/PRECISO  |PARA                |
|--------------------|------------------------------------|----------------------------------------|
|  Beneficiário (Ana) |Consultar em tempo real as ONGs ou abrigos disponíveis para distribuição de alimentos | Saber onde e quando posso obter alimentos de forma rápida e acessível|  
| Beneficiário (Lucas) | Receber notificações sobre as entregas de alimentos nas ONGs ou abrigos próximos a mim |Planejar melhor a minha ida aos locais de distribuição e não perder a oportunidade de receber alimentos. |



-------------------------------------------------------------------------------------------------------------------

|EU COMO| QUERO/PRECISO  |PARA                |
|--------------------|------------------------------------|----------------------------------------|
| Abrigo (Pedro)| Gerenciar as doações recebidas de forma eficiente| Distribuir alimentos aos moradores do abrigo de maneira organizada e sem desperdícios |
| Abrigo (Marta) | Monitorar a quantidade de alimentos estocados e as necessidades de doações|Planejar a reposição de estoque e garantir que nunca faltem alimentos para os moradores |                
| Abrigo (Fábio) | Receber alertas quando o estoque de alimentos estiver baixo | Evitar falta de alimentos e garantir que o abrigo esteja sempre abastecido |

--------------------------------------------------------------------------------------------------------------------

## Requisitos do Projeto

As tabelas que se seguem apresentam os requisitos funcionais e não funcionais que detalham o escopo do projeto. Para determinar a prioridade de requisitos, aplicar uma técnica de priorização de requisitos e detalhar como a técnica foi aplicada.

### Requisitos Funcionais

|ID    | Descrição do Requisito  | Prioridade |
|------|-----------------------------------------|----|
|RF-001| Permitir que o doador registre alimentos para doação | MÉDIA | 
|RF-002| Permitir a visualização das necessidades de ONGS e Abrigos | MÉDIA |
|RF-003| Agendamento de entregas e retirada | ALTA |
|RF-004| Cadastro de Beneficiários | BAIXA |
|RF-005| Cadastrar Voluntários e Entregadores | MÉDIA |
|RF-006| Permitir que os doadores acompanhem o status de suas doações em tempo real	 | MÉDIA |
|RF-007| Implementar um sistema de notificações para informar doadores, beneficiários e voluntários sobre atualizações importantes| ALTA |
|RF-008| Disponibilizar um relatório de doações realizadas, permitindo a visualização do histórico por período | BAIXA |

### Requisitos não Funcionais

[Utilize o modelo de tabela abaixo para apresentar os requisitos não-funcionais]

|ID     | Descrição do Requisito  |Prioridade |
|-------|-------------------------|----|
|RNF-001| Desempenho: O sistema deve ser capaz de processar até 1.000 transações simultâneas com tempo de resposta inferior a 7 segundos. | MÉDIA | 
|RNF-002| Segurança: O sistema deve garantir a segurança dos dados dos usuários através de autenticação por login e senha. |  ALTA | 
|RNF-003| Usabilidade: A interface deve de fácil navegação, garantindo uma experiência acessível para todos os usuários. O acesso deve ser feito por meio de sites, priorizando clareza e eficiência no design. | MÉDIA | 
|RNF-004| Compatibilidade: O sistema deve ser compatível com as versões mais recentes dos sistemas operacionais iOS e Android, além de navegadores modernos como Chrome, Firefox e Safari. | ALTA | 
|RNF-005| Disponibilidade: O sistema deve garantir uma taxa de disponibilidade de 99,9%, com exceção dos períodos de manutenção programada. | MÉDIA | 
|RNF-006| O sistema deve ser escalável para suportar um aumento de 50% na demanda sem degradação de desempenho.| MÉDIA | 
|RNF-007| Os dados pessoais dos usuários devem ser armazenados e tratados conforme a LGPD (Lei Geral de Proteção de Dados). | ALTA | 
|RNF-008| O sistema deve ser capaz de se recuperar automaticamente de falhas menores sem intervenção manual. | MÉDIA | 
