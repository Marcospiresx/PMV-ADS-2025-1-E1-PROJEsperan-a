# Template padrão da Aplicação

O layout principal do site foi desenvolvido utilizando HTML e CSS para estruturar e estilizar as páginas, enquanto o JavaScript foi empregado na criação do menu responsivo, garantindo uma melhor experiência em diferentes dispositivos.

Todas as páginas seguirão um padrão visual, contando com elementos fixos como o menu de navegação, o cabeçalho (header) e o rodapé (footer), além dos componentes de identidade visual descritos a seguir:

Cores: #60ab5e, #013d05, #000000 e #ffffff;
Font-family: Open Sans

Tela inicial:

![Inserir um subtítulo](https://github.com/user-attachments/assets/6b408703-d317-4bb8-bfbd-618fce2b11e3)

Tela de cadastro de doador ou beneficiário:

![Inserir um subtítulo (1)](https://github.com/user-attachments/assets/93899683-7582-4729-8af0-5c7529f01c18)

Tela de doação de alimentos:

![Inserir um subtítulo](https://github.com/user-attachments/assets/d16c7603-d25a-41d6-bcfa-41ba27fed930)

Tela de recebimento de doações:


![Inserir um subtítulo (3)](https://github.com/user-attachments/assets/fab7da74-df78-4113-991d-99c908620576)



Font-size: 12px, 20px e 30px.

Para a crição do Logotipo foi utilizado uma imagem do planeta terra e um símbolo de mãos entrelaçadas, representando a solidariedade, além do título do nosso projeto.


![Inserir um subtítulo (4)-Photoroom](https://github.com/user-attachments/assets/a55d76b4-951f-42f9-a6d9-73bd3434b8f5)


